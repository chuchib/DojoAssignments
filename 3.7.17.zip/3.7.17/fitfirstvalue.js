// Given two numbers, return array of length num1 with each value num2. Print "Jinx!" if they are same.

function fahrenheitToCelsius (fdegrees){
        var x= (fdegrees - 32)* (5/9)


        console.log(x);
      

}

  fahrenheitToCelsius (32);
