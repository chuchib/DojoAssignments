//Build a function that takes array of numbers. The function should print second-to-last value in the array, and return first odd value in the array.


function double(arr){

    var x = []
  for (var i = 0; i < arr.length; i++) {
      x. push( arr [i] *2 );
  }
    console.log(x);

}

double ([1,3,4,5]);
