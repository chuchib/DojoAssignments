//Create a function that takes array of numbers. The function should print the lowest value in the array, and return the highest value in the array.*/


function printreturn(arr){

  for(var i=0; i<arr.length; i++){
    if (arr [i] % 2 !==0){
      console.log (arr[arr.length-2]);
      return arr[i];
    }
  }

}

  printreturn ([1,3,4,5]);
