// Given two numbers, return array of length num1 with each value num2. Print "Jinx!" if they are same.

function  celsiusToFahrenheit(cDegrees){
        var x= ((9/5 * cDegrees) + 32);


        console.log(x);


}

 celsiusToFahrenheit (0);
