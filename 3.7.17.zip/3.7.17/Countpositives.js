//Given array of numbers, create function to replace last value with number of positive values.

function countpositives(arr){

    var x = 0
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] >0) {
      x ++;

    }
  }
    arr [ arr.length -1] = x;
    console.log(arr);

}

countpositives ([1,3,4,5]);
