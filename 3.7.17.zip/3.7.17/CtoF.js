//Given an array, write a function that changes all positive numbers in the array to “big”.

function makebig (arr) {
  for (var i = 0; i < arr.length; i++) {
    if (arr [i] >=0) {
      arr [i]="big"
    }
  } console.log (arr);
}

makebig([-1,3,5,-5])
