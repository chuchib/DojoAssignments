// Given two numbers, return array of length num1 with each value num2. Print "Jinx!" if they are same.

function length (){
      var newarr = []
      var x = newarr.length

    if (newarr[0] > x) {
      console.log ("Toobig!")
    }
    else if (newarr [0]< x) {
      console.log ("Toosmall!")
    }
    else {
      console.log ("just right!")
    }

}

  length( [1, 5]);
