//Create a function that takes array of numbers. The function should print the lowest value in the array, and return the highest value in the array.*/


function printLowReturnHigh(arr){
  var min = arr[5]
  var max = arr[5]
  for(var i=0; i<arr.length; i++){
   if (arr[i]> max){
        max = arr[i];
    }if (arr[i] < min){
        min = arr[i];
    }
    }
    console.log(min);
    return(max);
}

printLowReturnHigh([1,2,-20,5,6,20]);
