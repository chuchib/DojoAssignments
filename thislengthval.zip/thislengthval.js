// Given two numbers, return array of length num1 with each value num2. Print "Jinx!" if they are same.

function length (num1, num2){
      var newarr = []

      if (num1 === num2) {
        console.log ("Jinx!");
      }

        for (var i = 0; i < num1; i++) {
          newarr = newarr + num2;
        }

          console.log (newarr);

}

  length( 1, 5);
