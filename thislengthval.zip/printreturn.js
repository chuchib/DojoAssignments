var pluslength = function(arr) {
  return arr[0] + arr.length;
}

console.log(pluslength(["hello",6,7,5,4,9]));
