//
// function greaterthansec (array1) {
//       var arr =array1[1]
//
//       for (var i = 0; i <=array1.length; i++) {
//         // arr [i];
//         if (array1 [i] > arr) {
//
//           console.log (array1[i]);
//         }
//
//       }
//         return (array1.length -2);
//     }
//
//     greaterthansec([1,3,5,7,9,13])
function greaterThan2nd(arr){
  var y = arr[1];
  for(var i = 0; i<= arr.length; i++){
    if( arr[i] > y){
      console.log(arr[i]);
    }
  }
  return(arr.length-2);
}

greaterThan2nd([1,3,5,7,9,13])
