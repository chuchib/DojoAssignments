// Given two numbers, return array of length num1 with each value num2. Print "Jinx!" if they are same.

function length (num1, num2){
      var newarr = []

      for (var i = 0; i < num1; i++) {
        newarr= newarr + num2;
      }
      if (num1 === num2) {
        return ("Jinx!");
      }
}

length( 1, 3);
