function pr(num1, num2){
  var arr = [num1, num2]

      console.log(arr[0]);
  return arr [1];
}

pr(1,2);
